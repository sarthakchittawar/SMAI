examples folder contains two images; example1.png, example_solution.png
-> example1 shows how it looks when the boxes are connected to it's nearest box without any distance threshold. Observe that the boxes across columns and paragraphs are connected here.
-> example_solution shows how the final solution should look like. Distance thresholds are applied here to connect the boxes. Observe how the boxes are connected after applying a distance threshold.

images folder contains 10 different document images
CSV folder contains the csv files to the corresponding image. This csv contains the word level bounding box information.   